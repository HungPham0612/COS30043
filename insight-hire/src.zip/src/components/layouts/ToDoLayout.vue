<template>
    <div class="row justify-content-center">
      <div class="col-md-6">
        <router-view />
      </div>
    </div>
  </template>