<template>
    <div class="row justify-content-center">
      <div class="col-md-8">
        <router-view />
      </div>
    </div>
  </template>